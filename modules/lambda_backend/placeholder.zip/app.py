def handler(event, context):
    return {'statusCode': 200, 'body': 'medsense backend placeholder - deploy real code via CI'}
